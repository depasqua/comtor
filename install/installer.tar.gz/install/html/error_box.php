<?php
if (!empty($error))
{
  echo "<div class=\"error\">\n";
  echo $error;
  echo "</div>\n";
}
?>
