<h1>Setup Complete</h1>

<?php require_once("error_box.php"); ?>

<p>
Setup is now complete.  You may test out the system.
</p>
