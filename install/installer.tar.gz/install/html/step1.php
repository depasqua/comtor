<?php

// Check PHP version
$str = phpversion();
$php = (strlen($str > 0) && $str[0] == '5');

// Check for pear extensions
$pear_pswd = fileInIncludePath("Text/Password.php");
$pear_mail = fileInIncludePath("Mail.php");

// Check if the user defined a path to java
if (isset($_POST['javaPath']))
{
  if (empty($_POST['javaPath']))
    unset($_SESSION['javaPath']);
  else
    $_SESSION['javaPath'] = $_POST['javaPath'];
}
if (!isset($_SESSION['javaPath']))
  $_SESSION['javaPath'] = exec("which java", $out, $rtn);

// Check java version 1.5 or greater
define("JAVA_VERSION_REGEXP", "/\\\"1.[5-9].*\\\"/");
$out = array();
exec($_SESSION['javaPath']." -version 2>&1", $out, $rtn);
$java = (count($out) > 0 && preg_match(JAVA_VERSION_REGEXP, $out[0]));

// Check javadoc 
exec("which javadoc", $out, $rtn);
$javadoc = ($rtn == 0);

// Get Java CLASSPATH
$cp = exec("echo $CLASSPATH");
if (empty($cp))
  $cp = ".";

// Get path to jars
chdir("..");
$jars = getcwd() . DIRECTORY_SEPARATOR . "comtor_data" . DIRECTORY_SEPARATOR . "code" . DIRECTORY_SEPARATOR;
// Add all jars to the class path
if ($handle = opendir($jars)) 
{
  /* This is the correct way to loop over the directory. */
  define("JAR_REGEXP", "/.*\.jar$/");
  while (false !== ($file = readdir($handle)))
    if (preg_match(JAR_REGEXP, $file))
      $cp .= ":" . $jars . $file;
      
  $_POST['cp'] = $cp;  
  
  closedir($handle);
} 
chdir("install");

$antlr = $conJ = false;
if (chdir("code"))
{
  // Setup classpath
  $cpshell = "";
  if (isset($_POST['cp']))
  {
    $_SESSION['javacp'] = escapeshellarg($_POST['cp']);
    $cpshell = "-cp ".$_SESSION['javacp']." ";
  }

  // Check for ANTLR
  $antlr = false;
  if ($php)
  {
    $out = array();
    exec("javac {$cpshell} -d " . sys_get_temp_dir() . " AntlrCheck.java 2>&1", $out, $rtn);
    $antlr = ($rtn == 0);
    unlink(sys_get_temp_dir() . DIRECTORY_SEPARATOR . "AntlrCheck.class");
  }
  
  // Check for MySQL Connector/J
  define("CONNECTOR_J_REGEXP", "/^MySQL: Succeed$/");
  $out = array();
  exec($_SESSION['javaPath'] . " {$cpshell}SystemCheck 2>&1", $out, $rtn);
  $conJ = (count($out) > 0 && preg_match(CONNECTOR_J_REGEXP, $out[0]));  
  chdir("..");
}

// Check for crontab
$out = array();
exec("which crontab", $out, $rtn);
$cron = ($rtn == 0);

// Check if all checks passed
$pass = $php && $pear_pswd && $pear_mail && $java && $javadoc && $antlr && $conJ && $cron;

?>


<h1>Software Check</h1>

<?php require_once("error_box.php"); ?>

<p>
Checking for required software.
If any of the PEAR extensions fail, please install them and ensure that they are in the include path.
Please note that the "javadoc.sh" script requires some common utilities such as mkdir, rm, jar, javac, and find.  If you have issues submitting code, please check this file to determine where the script is looking for these utilities. 
You can find the software in the following locations:
</p>

<table>
<tr>
  <th>Software</th>
  <th>Location</th>
</tr>
<tr>
  <td>PHP 5</td>
  <td><a href="http://us.php.net">http://us.php.net</a></td>
</tr>
<tr>
  <td>PEAR</td>
  <td><a href="http://pear.php.net">http://pear.php.net</a></td>
</tr> 
<tr>
  <td>Java 1.5 or above</td>
  <td><a href="http://java.sun.com">http://java.sun.com</a></td>
</tr>
<tr>
  <td>Javadoc</td>
  <td><a href="http://java.sun.com/j2se/javadoc/">http://java.sun.com/j2se/javadoc/</a></td>
</tr>
<tr>
  <td>MySQL Connector/J</td>
  <td><a href="http://dev.mysql.com/downloads/connector/j/5.1.html">http://dev.mysql.com/downloads/connector/j/5.1.html</a></td>
</tr>
<tr>
  <td>ANTLR</td>
  <td><a href="http://www.antlr.org/download.html">http://www.antlr.org/download.html</a></td>
</tr>
</table>

<form name="form" method="post" action="">
<div>

  <fieldset>
    <legend>Java Settings</legend>
    <div class="floatContainer">
      <label for="javaPath">Java path: </label>
      <input id="javaPath" name="javaPath" type="text" value="<?php echo $_SESSION['javaPath']; ?>"/>
    </div>
    <div class="floatContainer">
      <label for="cp">Classpath: </label>
      <textarea id="cp" name="cp" rows="5" cols="50"><?php echo !empty($_POST['cp']) ? $_POST['cp'] : $cp; ?></textarea>
    </div>
  </fieldset>

  <table class="full">
  <tr>
    <td>PHP 5</td>
    <td class="status"><?php echo $php ? "<span class=\"succeed\">Success</span>" : "<span class=\"fail\">Failed</span>" ?></td>
  </tr>
  
  <tr>
    <td>PEAR Mail</td>
    <td class="status"><?php echo $pear_mail ? "<span class=\"succeed\">Success</span>" : "<span class=\"fail\">Failed</span>" ?></td>
  </tr>
  
  <tr>
    <td>PEAR Text/Password</td>
    <td class="status"><?php echo $pear_pswd ? "<span class=\"succeed\">Success</span>" : "<span class=\"fail\">Failed</span>" ?></td>
  </tr>

  <tr>
    <td>Java Version 1.5+</td>
    <td class="status"><?php echo $java ? "<span class=\"succeed\">Success</span>" : "<span class=\"fail\">Failed</span>" ?></td>
  </tr>
  
  <tr>
    <td>Javadoc</td>
    <td class="status"><?php echo $javadoc ? "<span class=\"succeed\">Success</span>" : "<span class=\"fail\">Failed</span>" ?></td>
  </tr>
  
  <tr>
    <td>MySQL Connector/J</td>
    <td class="status"><?php echo $conJ ? "<span class=\"succeed\">Success</span>" : "<span class=\"fail\">Failed</span>" ?></td>
  </tr>
  
  <tr>
    <td>Antlr</td>
    <td class="status"><?php echo $antlr ? "<span class=\"succeed\">Success</span>" : "<span class=\"fail\">Failed</span>" ?></td>
  </tr>

  <tr>
    <td>Crontab</td>
    <td class="status"><?php echo $cron ? "<span class=\"succeed\">Success</span>" : "<span class=\"fail\">Failed</span>" ?></td>
  </tr>
  </table>
  
  <input type="hidden" name="pass" value="<?php echo $pass ? "T" : "F"; ?>" />

  <span class="link" onclick="document.form.submit();"><?php echo $pass ? "Next" : "Check Again"; ?></span>
</div>
</form>
