import org.antlr.runtime.*;

public class AntlrCheck
{
  public static void main(String [] args)
  {
    System.out.println("Antlr found.");
  }
}

