<?php /* Smarty version 2.6.19, created on 2009-02-09 20:47:39
         compiled from acct_manage_all.tpl */ ?>
<?php echo '
<script type="text/javascript">
<!--
function verifyAction(action, name)
{
  return confirm("Are you sure you want to " + action + " the account for " + name);
}
//-->
</script>
'; ?>


<h1>Account Management</h1>

<?php if (is_array ( $this->_tpl_vars['usersE'] ) && count ( $this->_tpl_vars['usersE'] ) > 0): ?>
<table class="data">
<tr>
  <th>Name (School)</th>
  <th class="mini">Account Type</th>
  <th class="mini">Dropbox</th>
  <th class="mini">Reports</th>
  <th class="mini">Usage</th>
  <th>Actions</th>
</tr>

<?php $_from = $this->_tpl_vars['usersE']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['u']):
?>
<tr>
  <td class="left"><?php echo $this->_tpl_vars['u']['name']; ?>
<br/>(<?php echo $this->_tpl_vars['u']['school']; ?>
)  </td>
  <td class="mini"><?php echo $this->_tpl_vars['u']['acctType']; ?>
</td>
  <td class="mini center"><a href="dropbox.php?<?php if ($this->_tpl_vars['u']['acctType'] == 'professor'): ?>profId<?php else: ?>userId<?php endif; ?>=<?php echo $this->_tpl_vars['u']['userId']; ?>
"><img src="img/icons/magnifying_glass.gif" alt="View Dropbox" /></a></td>
  <td class="mini center"><a href="reports.php?<?php if ($this->_tpl_vars['u']['acctType'] == 'professor'): ?>profId<?php else: ?>userId<?php endif; ?>=<?php echo $this->_tpl_vars['u']['userId']; ?>
"><img src="img/icons/magnifying_glass.gif" alt="View Reports" /></a></td>
  <td class="mini center"><a href="usage.php?userId=<?php echo $this->_tpl_vars['u']['userId']; ?>
"><img src="img/icons/magnifying_glass.gif" alt="View Usage" /></a></td>
  <td>
    <a href="editAccount.php?userId=<?php echo $this->_tpl_vars['u']['userId']; ?>
"><img src="img/icons/edit.gif" alt="Edit" /></a>
    <a href="disableAccount.php?userId=<?php echo $this->_tpl_vars['u']['userId']; ?>
&amp;rand=<?php echo $this->_tpl_vars['rand']; ?>
" onclick="return verifyAction('disable', '<?php echo $this->_tpl_vars['u']['name']; ?>
');"><img src="img/icons/lock.gif" alt="Disable" /></a>
    <a href="deleteAccount.php?userId=<?php echo $this->_tpl_vars['u']['userId']; ?>
&amp;rand=<?php echo $this->_tpl_vars['rand']; ?>
" onclick="return verifyAction('delete', '<?php echo $this->_tpl_vars['u']['name']; ?>
');"><img src="img/icons/delete.gif" alt="Delete" /></a>
  </td>
</tr>
<?php endforeach; endif; unset($_from); ?>

</table>
<?php else: ?>
<h5 class="center">No Results Found.</h5>
<?php endif; ?>

<?php echo $this->_tpl_vars['usersELinks']; ?>


<br />

<h1>Disabled Accounts</h1>

<?php if (is_array ( $this->_tpl_vars['usersD'] ) && count ( $this->_tpl_vars['usersD'] ) > 0): ?>
<table class="data">
<tr>
  <th>Name (School)</th>
  <th class="mini">Account Type</th>
  <th class="mini">Reports</th>
  <th class="mini">Usage</th>
  <th>Actions</th>
</tr>

<?php $_from = $this->_tpl_vars['usersD']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['u']):
?>
<tr>
  <td class="left"><?php echo $this->_tpl_vars['u']['name']; ?>
<br/>(<?php echo $this->_tpl_vars['u']['school']; ?>
)  </td>
  <td class="mini"><?php echo $this->_tpl_vars['u']['acctType']; ?>
</td>
  <td class="mini center"><a href="reports.php?profId=<?php echo $this->_tpl_vars['u']['userId']; ?>
"><img src="img/icons/magnifying_glass.gif" alt="View Reports" /></a></td>
  <td class="mini center"><a href="usage.php?userId=<?php echo $this->_tpl_vars['u']['userId']; ?>
"><img src="img/icons/magnifying_glass.gif" alt="View Usage" /></a></td>
  <td>
    <a href="editAccount.php?userId=<?php echo $this->_tpl_vars['u']['userId']; ?>
"><img src="img/icons/edit.gif" alt="Edit" /></a>
    <a href="enableAccount.php?userId=<?php echo $this->_tpl_vars['u']['userId']; ?>
&amp;rand=<?php echo $this->_tpl_vars['rand']; ?>
" onclick="return verifyAction('enable', '<?php echo $this->_tpl_vars['u']['name']; ?>
');"><img src="img/icons/unlock.gif" alt="Enable" /></a>
    <a href="deleteAccount.php?userId=<?php echo $this->_tpl_vars['u']['userId']; ?>
&amp;rand=<?php echo $this->_tpl_vars['rand']; ?>
" onclick="return verifyAction('delete', '<?php echo $this->_tpl_vars['u']['name']; ?>
');"><img src="img/icons/delete.gif" alt="Delete" /></a>
  </td>
</tr>
<?php endforeach; endif; unset($_from); ?>

</table>
<?php else: ?>
<h5 class="center">No Results Found.</h5>
<?php endif; ?>

<?php echo $this->_tpl_vars['usersDLinks']; ?>
