<?php /* Smarty version 2.6.19, created on 2009-02-09 20:45:26
         compiled from requests.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'default', 'requests.tpl', 4, false),array('modifier', 'capitalize', 'requests.tpl', 10, false),)), $this); ?>
<h3>Requests</h3>

<?php if (((is_array($_tmp=@$this->_tpl_vars['req_acctType'])) ? $this->_run_mod_handler('default', true, $_tmp, false) : smarty_modifier_default($_tmp, false))): ?>
  <form name="acctTypeForm" method="GET" action="requestChangeAcctType.php">
    <fieldset>
    <legend>Account Type<legend>
    <select name="acctType">
      <?php $_from = $this->_tpl_vars['acctTypes']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['type']):
?>
        <option value="<?php echo $this->_tpl_vars['type']; ?>
" <?php if ($this->_tpl_vars['type'] == $this->_tpl_vars['acctType']): ?>selected="selected"<?php endif; ?>><?php echo ((is_array($_tmp=$this->_tpl_vars['type'])) ? $this->_run_mod_handler('capitalize', true, $_tmp) : smarty_modifier_capitalize($_tmp)); ?>
</option>
      <?php endforeach; endif; unset($_from); ?>
    </select>
    <br/>
    <label for="comment">Please provide a short comment or link to a website indicating why your account type should be changed:</label>
    <br/>
    <input type="text" id="comment" name="comment" style="width: 100%;"/>
    <br/>
    <input type="hidden" name="userId" value="<?php echo $this->_tpl_vars['userId']; ?>
" />
    <a href="javascript:document.acctTypeForm.submit();">Request Account Type Change</a>
    </fieldset>
  </form>
<?php endif; ?>
<?php if (((is_array($_tmp=@$this->_tpl_vars['req_acctDelete'])) ? $this->_run_mod_handler('default', true, $_tmp, false) : smarty_modifier_default($_tmp, false))): ?>
  <a href="requestRemoveAcct.php">Request Account Removal</a>
<?php endif; ?>


<h4>Account Type Change Requests</h4>
<?php if (is_array ( $this->_tpl_vars['req_acct_type'] ) && count ( $this->_tpl_vars['req_acct_type'] ) > 0): ?>
<table class="data">
<tr>
  <?php if ($_SESSION['userId'] != $this->_tpl_vars['userId']): ?>
    <th>User</th>
  <?php endif; ?>
  <th>Account Type</th>
  <th>Comment</th>
  <th>Status</th>
  <th class="large">Actions</th>
</tr>

<?php $_from = $this->_tpl_vars['req_acct_type']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['req']):
?>
<tr>
  <?php if ($_SESSION['userId'] != $this->_tpl_vars['userId']): ?>
    <td><?php echo $this->_tpl_vars['req']['name']; ?>
</td>
  <?php endif; ?>
  <td><?php echo $this->_tpl_vars['req']['acct_type']; ?>
</td>
  <td><?php echo $this->_tpl_vars['req']['comment']; ?>
</td>
  <td><?php echo $this->_tpl_vars['req']['status']; ?>
</td>
    <td>
    <a href="request_delete.php?type=acctType&amp;req_id=<?php echo $this->_tpl_vars['req']['req_id']; ?>
">Delete Request</a>
    <?php if ($_SESSION['acctType'] == 'admin'): ?>
      <br/>
      <a href="request_accept.php?type=acctType&amp;req_id=<?php echo $this->_tpl_vars['req']['req_id']; ?>
">Accept Request</a>
      <br/>
      <a href="request_reject.php?type=acctType&amp;req_id=<?php echo $this->_tpl_vars['req']['req_id']; ?>
">Reject Request</a>
    <?php endif; ?>
  </td>
</tr>
<?php endforeach; endif; unset($_from); ?>

</table>
<?php elseif (((is_array($_tmp=@$this->_tpl_vars['resultMsg'])) ? $this->_run_mod_handler('default', true, $_tmp, true) : smarty_modifier_default($_tmp, true))): ?>
<h5 class="center">No Results Found</h5>
<?php endif; ?>


<h4>Account Removal Requests</h4>
<?php if (is_array ( $this->_tpl_vars['req_acct_removal'] ) && count ( $this->_tpl_vars['req_acct_removal'] ) > 0): ?>
<table class="data">
<tr>
  <?php if ($_SESSION['userId'] != $this->_tpl_vars['userId']): ?>
    <th>User</th>
  <?php endif; ?>
  <th>Status</th>
  <th class="large">Actions</th>
</tr>

<?php $_from = $this->_tpl_vars['req_acct_removal']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['req']):
?>
<tr>
  <?php if ($_SESSION['userId'] != $this->_tpl_vars['userId']): ?>
    <td><?php echo $this->_tpl_vars['req']['name']; ?>
</td>
  <?php endif; ?>
  <td><?php echo $this->_tpl_vars['req']['status']; ?>
</td>
    <td>
    <a href="request_delete.php?type=acctRemove&amp;userId=<?php echo $this->_tpl_vars['req']['userId']; ?>
">Delete Request</a>
    <?php if ($_SESSION['acctType'] == 'admin'): ?>
      <br/>
      <a href="request_accept.php?type=acctRemove&amp;userId=<?php echo $this->_tpl_vars['req']['userId']; ?>
">Accept Request</a>
      <br/>
      <a href="request_reject.php?type=acctRemove&amp;userId=<?php echo $this->_tpl_vars['req']['userId']; ?>
">Reject Request</a>
    <?php endif; ?>
  </td>
</tr>
<?php endforeach; endif; unset($_from); ?>

</table>
<?php elseif (((is_array($_tmp=@$this->_tpl_vars['resultMsg'])) ? $this->_run_mod_handler('default', true, $_tmp, true) : smarty_modifier_default($_tmp, true))): ?>
<h5 class="center">No Results Found</h5>
<?php endif; ?>