<?php /* Smarty version 2.6.19, created on 2009-02-09 20:45:11
         compiled from htmlmain.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'default', 'htmlmain.tpl', 12, false),)), $this); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <link rel="icon" type="image/gif" href="favicon.gif" />
  <link rel="shortcut icon" type="image/vnd.microsoft.icon" href="favicon.ico" />
  <link rel="stylesheet" type="text/css" href="css/tables.css" />
  <link rel="stylesheet" type="text/css" href="css/layout.css" />
  <link rel="stylesheet" type="text/css" media="print" href="css/print.css" />

  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

  <title><?php echo ((is_array($_tmp=@$this->_tpl_vars['windowTitle'])) ? $this->_run_mod_handler('default', true, $_tmp, 'COMTOR') : smarty_modifier_default($_tmp, 'COMTOR')); ?>
</title>
</head>

<body>
<?php if (((is_array($_tmp=@DEVELOPMENT)) ? $this->_run_mod_handler('default', true, $_tmp, false) : smarty_modifier_default($_tmp, false))): ?>
  <div style="position: absolute; right: 10px; font-size: 50px; font-weight: bold; color: #a00000;">Development</div>
<?php endif; ?>

<img alt="COMTOR Logo" src="img/logo.gif" />

<div class="header_bar">
  <div class="bar_left"></div>
  <div class="bar_right"></div>
  <div class="bar_mid_frame">
    <div class="bar_mid">
      <?php if (isset ( $_SESSION['username'] )): ?>
        <div class="username"><?php echo $_SESSION['username']; ?>
<a href="logout.php">(Logout)</a></div>
      <?php endif; ?>
      <?php if (isset ( $this->_tpl_vars['courses'] ) && count ( $this->_tpl_vars['courses'] ) > 0): ?>
        <div class="course_select">
          <?php if ($_SESSION['acctType'] == 'student'): ?>
            <?php $this->assign('coursePage', 'reports.php'); ?>
          <?php else: ?>
            <?php $this->assign('coursePage', 'courseManage.php'); ?>
          <?php endif; ?>
          <?php echo '
          <script type="text/javascript">
          <!--
          function CourseSelected()
          {
            var courseId = document.getElementById("courseId").value;
            if (courseId != -1 '; ?>
<?php if (isset ( $_SESSION['courseId'] )): ?>&& courseId != <?php echo $_SESSION['courseId']; ?>
<?php endif; ?><?php echo ')
            {
              //var url = "'; ?>
<?php echo $this->_tpl_vars['coursePage']; ?>
<?php echo '?courseId=" + courseId;
              var url = "?courseId=" + courseId;
              window.location = url;
            }
          }
          //-->
          </script>
          '; ?>

          <select id="courseId" name="courseId" onchange="CourseSelected();" >
            <option value="-1">Course Select</option>
            <?php $_from = $this->_tpl_vars['courses']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['c']):
?>
              <option value="<?php echo $this->_tpl_vars['c']['courseId']; ?>
" <?php if ($_SESSION['courseId'] == $this->_tpl_vars['c']['courseId']): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['c']['semester']; ?>
: <?php echo $this->_tpl_vars['c']['section']; ?>
</option>
            <?php endforeach; endif; unset($_from); ?>
          </select>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- Sidebar -->
<div class="sidebar">

<!-- Modules -->
<?php if (is_array ( $this->_tpl_vars['modules'] ) && count ( $this->_tpl_vars['modules'] ) > 0): ?>
<div class="sidelinks">
  <div class="mod_top"></div>
  <div class="side_mid">
    <div class="side_mid_content">
      <ul>
      <?php $_from = $this->_tpl_vars['modules']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['m']):
?>
        <li><a href="<?php echo $this->_tpl_vars['m']->href; ?>
" <?php $_from = $this->_tpl_vars['m']->attrs; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['a']):
?><?php echo $this->_tpl_vars['a']->attr; ?>
="<?php echo $this->_tpl_vars['a']->value; ?>
"<?php endforeach; endif; unset($_from); ?>><?php echo $this->_tpl_vars['m']->name; ?>
</a></li>
      <?php endforeach; endif; unset($_from); ?>
      </ul>
    </div>
  </div>
  <div class="side_bottom"></div>
</div>
<?php endif; ?>

  <!-- Comtor Links -->
  <div class="sidelinks">
    <div class="comtor_top"></div>
    <div class="side_mid">
      <div class="side_mid_content">
        <ul>
           <?php $_from = $this->_tpl_vars['comtorLinks']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['c']):
?>
            <li><a href="<?php echo $this->_tpl_vars['c']->href; ?>
" <?php $_from = $this->_tpl_vars['m']->attrs; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['a']):
?><?php echo $this->_tpl_vars['a']->attr; ?>
="<?php echo $this->_tpl_vars['a']->value; ?>
"<?php endforeach; endif; unset($_from); ?>><?php echo $this->_tpl_vars['c']->name; ?>
</a></li>
          <?php endforeach; endif; unset($_from); ?>
          <li><a href="features.php">Features We Measure</a></li>
          <li><a href="faq.php">FAQ</a></li>
          <li><a href="tutorials.php">Video Tutorials</a></li>
        </ul>
      </div>
    </div>
    <div class="side_bottom"></div>
  </div>

<!-- End Sidebar -->
</div>

<div class="main_column">
  <div class="content_frame">
    <div class="content">

        <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "template_breadcrumbs.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

    <?php if (isset ( $this->_tpl_vars['success'] )): ?><div class="success"><?php echo $this->_tpl_vars['success']; ?>
</div><?php endif; ?>
    <?php if (isset ( $this->_tpl_vars['error'] )): ?><div class="error"><?php echo $this->_tpl_vars['error']; ?>
</div><?php endif; ?>

    <?php echo $this->_tpl_vars['tpldata']; ?>


    </div>
  </div>
</div>

<div class="footer">
  <a href="about.php">About Comment Mentor</a><br/>
  Copyright &copy; 2006 TCNJ
  <div class="tcnj_logo">
    <a href="http://www.tcnj.edu"><img src="img/tcnj_logo-small.gif" alt="TCNJ Logo" border="0" /></a>
  </div>
</div>

</body>
</html>