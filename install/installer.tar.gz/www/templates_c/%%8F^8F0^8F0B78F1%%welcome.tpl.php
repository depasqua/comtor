<?php /* Smarty version 2.6.19, created on 2009-02-09 20:45:20
         compiled from welcome.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'default', 'welcome.tpl', 6, false),)), $this); ?>
<div class='center'>Welcome to COMTOR.  Please use the links to the left to navigate the different pages.</div>

<h3>Courses</h3>
<?php if (is_array ( $this->_tpl_vars['courses'] ) && count ( $this->_tpl_vars['courses'] ) > 0): ?>
  <?php $_from = $this->_tpl_vars['courses']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['c']):
?>
    <h4><a href="<?php echo ((is_array($_tmp=@$this->_tpl_vars['url'])) ? $this->_run_mod_handler('default', true, $_tmp, 'courses.php') : smarty_modifier_default($_tmp, 'courses.php')); ?>
?courseId=<?php echo $this->_tpl_vars['c']['courseId']; ?>
"><?php echo $this->_tpl_vars['c']['section']; ?>
: <?php echo $this->_tpl_vars['c']['name']; ?>
 (<?php echo $this->_tpl_vars['c']['semester']; ?>
)</a></h4>
  <?php endforeach; endif; unset($_from); ?>
<?php elseif (((is_array($_tmp=@$this->_tpl_vars['resultMsg'])) ? $this->_run_mod_handler('default', true, $_tmp, true) : smarty_modifier_default($_tmp, true))): ?>
  <h5 class="center">No Results Found</h5>
<?php endif; ?>