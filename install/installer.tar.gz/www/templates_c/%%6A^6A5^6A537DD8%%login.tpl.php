<?php /* Smarty version 2.6.19, created on 2009-02-09 20:45:11
         compiled from login.tpl */ ?>
<?php echo '
<script type="text/javascript">
function verify()
{
  var themessage = "You are required to complete the following fields: ";
  if (document.form.email.value=="")
  {
    themessage = themessage + " - Email";
  }
  if (document.form.password.value=="")
  {
    themessage = themessage + " -  Password";
  }
  // Alert if fields are empty and cancel form submit
  if (themessage != "You are required to complete the following fields: ")
  {
    alert(themessage);
    return false;
  }
}
</script>
'; ?>


<form action="login.php" method="post" name="form">
<table id="frame">
 <tr>
  <td>Email:</td>
 <tr>
  <td><input type="text" name="email"></td>
 <tr>
  <td>Password:</td>
 <tr>
  <td><input type="password" name="password"></td>
 <tr>
  <td><input type="submit" name="submit" value="Login" onClick="return verify();"></td>
</table>
</form>

Need an account? <a href="registerForm.php">Register Here</a>