<?php /* Smarty version 2.6.19, created on 2009-02-09 20:45:25
         compiled from course_add.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'default', 'course_add.tpl', 31, false),array('modifier', 'date_format', 'course_add.tpl', 71, false),)), $this); ?>
<?php echo '
<script type=\'text/javascript\'>
function verify()
{
  var message = "";
  // Determine if course section is set
  if (document.courseForm.section.value == "")
  {
    message += " - Course section\\n";
  }
  // Determine if course name is set
  if (document.courseForm.name.value == "")
  {
    message += " - Course name\\n";
  }

  // Alert if fields are empty and cancel form submit
  if(message != "")
  {
    message = "You are required to complete the following fields:\\n" + message;
    alert(message);
    return false;
  }

  // Return true if there were no problems
  return true;
}
</script>
'; ?>


<h1><?php if (((is_array($_tmp=@$this->_tpl_vars['edit'])) ? $this->_run_mod_handler('default', true, $_tmp, false) : smarty_modifier_default($_tmp, false))): ?>Edit<?php else: ?>Add<?php endif; ?> Course</h1>

<form name="courseForm" method="post" action="course<?php if (((is_array($_tmp=@$this->_tpl_vars['edit'])) ? $this->_run_mod_handler('default', true, $_tmp, false) : smarty_modifier_default($_tmp, false))): ?>Edit<?php else: ?>Add<?php endif; ?>.php">
<div class="center">
  <div>
    <span class="formLabel">Course Section:</span>
    <input name="section" size="20" maxlength="20" type="text" value="<?php echo $this->_tpl_vars['section']; ?>
">
  </div>

  <div>
    <span class="formLabel">Course Name:</span>
    <input name="name" size="50" maxlength="255" type="text" value="<?php echo $this->_tpl_vars['name']; ?>
">
  </div>

  <?php if (is_array ( $this->_tpl_vars['profs'] ) && count ( $this->_tpl_vars['profs'] ) > 0): ?>
  <!-- Course professor -->
  <div>
    <span class="formLabel">Professor:</span>
    <select name="professor">
    <?php $_from = $this->_tpl_vars['profs']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['p']):
?>
      <option value="<?php echo $this->_tpl_vars['p']['userId']; ?>
" <?php if ($this->_tpl_vars['profId'] == $this->_tpl_vars['p']['userId']): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['p']['name']; ?>
</option>
    <?php endforeach; endif; unset($_from); ?>
    </select>
  </div>
  <?php endif; ?>

  <div>
    <!-- Course semester -->
    <span class="formLabel">Course Semester:</span>
    <select name="semester">
      <option value="Fall" <?php if ($this->_tpl_vars['semester'] == 'Fall'): ?>selected="selected"<?php endif; ?>>Fall</option>
      <option value="Winter" <?php if ($this->_tpl_vars['semester'] == 'Winter'): ?>selected="selected"<?php endif; ?>>Winter</option>
      <option value="Spring" <?php if ($this->_tpl_vars['semester'] == 'Spring'): ?>selected="selected"<?php endif; ?>>Spring</option>
      <option value="Summer" <?php if ($this->_tpl_vars['semester'] == 'Summer'): ?>selected="selected"<?php endif; ?>>Summer</option>
    </select>

    <!-- Course year -->
    <span class="formLabel">Year:</span>
    <select name="year">
      <?php if (! isset ( $this->_tpl_vars['year'] )): ?>
        <?php $this->assign('year', ((is_array($_tmp=time())) ? $this->_run_mod_handler('date_format', true, $_tmp, '%Y') : smarty_modifier_date_format($_tmp, '%Y'))); ?>
      <?php endif; ?>
      <?php unset($this->_sections['y']);
$this->_sections['y']['name'] = 'y';
$this->_sections['y']['start'] = (int)$this->_tpl_vars['start_year'];
$this->_sections['y']['loop'] = is_array($_loop=$this->_tpl_vars['end_year']+1) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['y']['show'] = true;
$this->_sections['y']['max'] = $this->_sections['y']['loop'];
$this->_sections['y']['step'] = 1;
if ($this->_sections['y']['start'] < 0)
    $this->_sections['y']['start'] = max($this->_sections['y']['step'] > 0 ? 0 : -1, $this->_sections['y']['loop'] + $this->_sections['y']['start']);
else
    $this->_sections['y']['start'] = min($this->_sections['y']['start'], $this->_sections['y']['step'] > 0 ? $this->_sections['y']['loop'] : $this->_sections['y']['loop']-1);
if ($this->_sections['y']['show']) {
    $this->_sections['y']['total'] = min(ceil(($this->_sections['y']['step'] > 0 ? $this->_sections['y']['loop'] - $this->_sections['y']['start'] : $this->_sections['y']['start']+1)/abs($this->_sections['y']['step'])), $this->_sections['y']['max']);
    if ($this->_sections['y']['total'] == 0)
        $this->_sections['y']['show'] = false;
} else
    $this->_sections['y']['total'] = 0;
if ($this->_sections['y']['show']):

            for ($this->_sections['y']['index'] = $this->_sections['y']['start'], $this->_sections['y']['iteration'] = 1;
                 $this->_sections['y']['iteration'] <= $this->_sections['y']['total'];
                 $this->_sections['y']['index'] += $this->_sections['y']['step'], $this->_sections['y']['iteration']++):
$this->_sections['y']['rownum'] = $this->_sections['y']['iteration'];
$this->_sections['y']['index_prev'] = $this->_sections['y']['index'] - $this->_sections['y']['step'];
$this->_sections['y']['index_next'] = $this->_sections['y']['index'] + $this->_sections['y']['step'];
$this->_sections['y']['first']      = ($this->_sections['y']['iteration'] == 1);
$this->_sections['y']['last']       = ($this->_sections['y']['iteration'] == $this->_sections['y']['total']);
?>
        <option value="<?php echo $this->_sections['y']['index']; ?>
" <?php if ($this->_tpl_vars['year'] == $this->_sections['y']['index']): ?>selected="selected"<?php endif; ?>><?php echo $this->_sections['y']['index']; ?>
</option>
      <?php endfor; endif; ?>
    </select>

  </div>

  <!-- Course comments -->
  <div class="courseComments" style="margin: 0px auto; width: 250px; text-align: left;">
    <span class="formLabel">Comments:</span>
    <br>
    <textarea name="comment" style="width: 100%; height: 75px;"><?php echo $this->_tpl_vars['comment']; ?>
</textarea>
  </div>

  <?php if (((is_array($_tmp=@$this->_tpl_vars['edit'])) ? $this->_run_mod_handler('default', true, $_tmp, false) : smarty_modifier_default($_tmp, false))): ?>
    <input name="courseId" value="<?php echo $this->_tpl_vars['courseId']; ?>
" type="hidden" />
  <?php endif; ?>
  <input name="securityRand" value="<?php echo $this->_tpl_vars['rand']; ?>
" type="hidden" />
  <input name="securityPage" value="<?php echo $this->_tpl_vars['page_sec']; ?>
" type="hidden" />
  <input class="submit" onclick="return verify();" value="Submit" type="submit">
</div>
</form>