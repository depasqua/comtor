<?php /* Smarty version 2.6.19, created on 2009-02-09 20:45:24
         compiled from doclet_usage.tpl */ ?>
<?php if (is_array ( $this->_tpl_vars['doclets'] ) && count ( $this->_tpl_vars['doclets'] ) > 0): ?>
  <h3>Doclet Usage</h3>
  <?php $_from = $this->_tpl_vars['doclets']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['d']):
?>
    <h6><?php echo $this->_tpl_vars['d']['docletName']; ?>
: </h6> selected <?php echo $this->_tpl_vars['d']['numRows']; ?>
 times<br/>
  <?php endforeach; endif; unset($_from); ?>
<?php endif; ?>