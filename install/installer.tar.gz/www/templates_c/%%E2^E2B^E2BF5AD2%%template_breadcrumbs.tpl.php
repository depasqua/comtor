<?php /* Smarty version 2.6.19, created on 2009-02-09 20:45:11
         compiled from template_breadcrumbs.tpl */ ?>
<div class="breadcrumbs">
<?php $_from = $this->_tpl_vars['breadcrumbs']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }$this->_foreach['breadcrumbs'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['breadcrumbs']['total'] > 0):
    foreach ($_from as $this->_tpl_vars['crumb']):
        $this->_foreach['breadcrumbs']['iteration']++;
?>
  <?php if (! ($this->_foreach['breadcrumbs']['iteration'] == $this->_foreach['breadcrumbs']['total'])): ?>
    <a href="<?php echo $this->_tpl_vars['crumb']['href']; ?>
"><?php echo $this->_tpl_vars['crumb']['text']; ?>
</a> &raquo;
  <?php else: ?>
    <?php echo $this->_tpl_vars['crumb']['text']; ?>

  <?php endif; ?>
<?php endforeach; endif; unset($_from); ?>
</div>