<?php /* Smarty version 2.6.19, created on 2009-02-09 20:45:24
         compiled from usage.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'strtodate', 'usage.tpl', 7, false),)), $this); ?>
<h1>System Usage</h1>
<h6>Name: </h6><?php echo $this->_tpl_vars['name']; ?>
<br/>
<h6>E-Mail Address: </h6><?php echo $this->_tpl_vars['email']; ?>
<br/>
<h6>School: </h6><?php echo $this->_tpl_vars['school']; ?>
<br/>

<h3>Account History</h3>
<h6>Account created: </h6><?php echo smarty_function_strtodate(array('format' => $this->_tpl_vars['dateFormat'],'date' => $this->_tpl_vars['dateTime']), $this);?>
<br/>
<h6>Account Validated: </h6><?php echo smarty_function_strtodate(array('format' => $this->_tpl_vars['dateFormat'],'date' => $this->_tpl_vars['validatedDT']), $this);?>
<br/>
<h6>Password last changed: </h6><?php echo smarty_function_strtodate(array('format' => $this->_tpl_vars['dateFormat'],'date' => $this->_tpl_vars['passwordChangeDT']), $this);?>
<br/>
<h6>Last login: </h6><?php echo smarty_function_strtodate(array('format' => $this->_tpl_vars['dateFormat'],'date' => $this->_tpl_vars['lastLogin']), $this);?>
<br/>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "doclet_usage.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>