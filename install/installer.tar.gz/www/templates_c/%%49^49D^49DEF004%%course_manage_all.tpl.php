<?php /* Smarty version 2.6.19, created on 2009-02-09 20:45:27
         compiled from course_manage_all.tpl */ ?>
<?php echo '
<script type="text/javascript">
<!--
function verifyCourseAction(action, section, name, professor, semester)
{
  return confirm("Are you sure you want to " + action + " the following course:\\nSection: " + section + "\\nName: " + name + "\\nProfessor: " + professor + "\\nSemester: " + semester);
}
//-->
</script>
'; ?>


<h1>Courses</h1>

<?php if (isset ( $this->_tpl_vars['courses_all'] )): ?>
  <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "course_list.tpl", 'smarty_include_vars' => array('courses_all' => $this->_tpl_vars['courses_all'],'pages' => $this->_tpl_vars['pages_all'],'resultMsg' => "isset(".($this->_tpl_vars['courses_all']).")")));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php endif; ?>
<?php if (isset ( $this->_tpl_vars['courses_enabled'] )): ?>
  <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "course_list.tpl", 'smarty_include_vars' => array('courses_all' => $this->_tpl_vars['courses_enabled'],'pages' => $this->_tpl_vars['pages_enabled'],'resultMsg' => $this->_tpl_vars['courses_enabled'],'group_title' => 'Enabled')));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php endif; ?>
<?php if (isset ( $this->_tpl_vars['courses_disabled'] )): ?>
  <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "course_list.tpl", 'smarty_include_vars' => array('courses_all' => $this->_tpl_vars['courses_disabled'],'pages' => $this->_tpl_vars['pages_disabled'],'group_title' => 'Disabled')));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php endif; ?>