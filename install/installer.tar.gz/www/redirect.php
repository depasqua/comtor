<?
  require_once("config.php");
  header("Location: http://" . URL_PATH);
  exit;
?>
