<?php
  // Define private directory where config.php is
  define("PRIVATE_DIR", "/home/comtor/private/comtor_dev/");

  require_once(PRIVATE_DIR."config.php");
?>
