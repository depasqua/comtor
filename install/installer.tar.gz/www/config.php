<?php
  // Define private directory where config.php is
  define("PRIVATE_DIR", "/home/sigwart4/public_html/comtor_data/config/");

  require_once(PRIVATE_DIR."config.php");

?>